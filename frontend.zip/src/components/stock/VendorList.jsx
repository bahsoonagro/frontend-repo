// Dashboard.jsx
import React from 'react';

const Dashboard = () => {
  return <div className="bg-white shadow p-4 rounded">Dashboard Overview</div>;
};

export default Dashboard;

